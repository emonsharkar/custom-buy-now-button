<?php
/**
 * Plugin Name: Custom Buy Now Button
 * Description: Customizes Buy Now Button as you wish. Adds a Gutenberg block, Elementor widget and shortcode to place a "Buy Now" button that adds a product to the cart and takes the customer directly to Checkout.
 * Version: 1.5
 * Author: MD EMON SHARKAR
 * Author URI: https://github.com/emonsharkar
 * Requires Plugins: woocommerce
 * Text Domain: custom-buy-now
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'CBN_PLUGIN_VERSION', '1.2' );
define( 'CBN_PLUGIN_FILE', __FILE__ );
define( 'CBN_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CBN_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

function cbn_wc_active() { return class_exists( 'WooCommerce' ) && function_exists( 'WC' ); }

add_filter( 'query_vars', function( $vars ) { $vars[]='custom-buy-now'; $vars[]='qty'; return $vars; });

add_action( 'template_redirect', function() {
    if ( ! cbn_wc_active() ) { return; }
    $product_id = absint( get_query_var( 'custom-buy-now' ) );
    if ( ! $product_id ) { return; }
    $qty = absint( get_query_var( 'qty' ) ); if ( $qty < 1 ) { $qty = 1; }
    $product = wc_get_product( $product_id );
    if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
        wc_add_notice( __( 'This product cannot be purchased at the moment.', 'custom-buy-now' ), 'error' );
        wp_safe_redirect( wc_get_cart_url() ); exit;
    }
    WC()->cart->add_to_cart( $product_id, $qty );
    wp_safe_redirect( wc_get_checkout_url() ); exit;
});

function cbn_get_buy_now_url( $product_id, $qty = 1 ) {
    return add_query_arg( array('custom-buy-now'=>absint($product_id),'qty'=>max(1,absint($qty))), home_url('/') );
}

function cbn_get_icon_svg( $name = 'cart' ) {
    $icons = array(
        'cart'   => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M7 4h-2l-1 2H2v2h2l3.6 7.59-1.35 2.44A2 2 0 0 0 6.5 20 2 2 0 0 0 8 24a2 2 0 1 0 0-4H18a2 2 0 1 0 0 4 2 2 0 0 0 1.73-3H9.42a.25.25 0 0 1-.22-.37l.93-1.63h7.07a2 2 0 0 0 1.79-1.11l3.58-7.16A1 1 0 0 0 22 6H7.21L7 4z"/></svg>',
        'bag'    => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M7 7V6a5 5 0 0 1 10 0v1h2a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h2zm2 0h6V6a3 3 0 0 0-6 0v1z"/></svg>',
        'bolt'   => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M11 21l1-7H8l7-11-1 7h4l-7 11z"/></svg>',
        'flash'  => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M7 2l10 9h-6l2 11L3 11h6L7 2z"/></svg>',
        'credit' => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M2 5h20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zm0 4h20V7H2v2zm4 5v2h6v-2H6z"/></svg>',
        'arrow'  => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M13 5l7 7-7 7v-4H4v-6h9V5z"/></svg>',
        'check'  => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M20.285 6.708l-11.03 11.03-5.54-5.54 1.414-1.414 4.126 4.126 9.616-9.616z"/></svg>',
        'star'   => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>',
        'tag'    => '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M21.41 11.58l-9-9A2 2 0 0 0 11 2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 .59 1.41l9 9a2 2 0 0 0 2.82 0l7-7a2 2 0 0 0 0-2.83zM7.5 8A1.5 1.5 0 1 1 9 6.5 1.5 1.5 0 0 1 7.5 8z"/></svg>',
    );
    $name = strtolower( sanitize_key( $name ) );
    return isset( $icons[ $name ] ) ? $icons[ $name ] : $icons['cart'];
}

add_shortcode( 'custom_buy_now', function( $atts ) {
    if ( ! cbn_wc_active() ) { return ''; }
    $atts = shortcode_atts( array(
        'product_id' => 0, 'quantity' => 1, 'text' => __( 'Buy Now', 'custom-buy-now' ),
        'variant' => 'outline', 'size' => 'md', 'fullwidth' => 'no',
        'icon' => 'yes', 'icon_name' => 'cart', 'icon_pos' => 'left',
        'animation' => 'lift', 'class' => '',
    ), $atts, 'custom_buy_now' );

    $product_id = absint( $atts['product_id'] );
    if ( ! $product_id ) return '<em>' . esc_html__( 'Select a Product ID', 'custom-buy-now' ) . '</em>';

    $url = cbn_get_buy_now_url( $product_id, $atts['quantity'] );
    $icon = ( 'yes' === $atts['icon'] ) ? '<span class="cbn-icon" aria-hidden="true">' . cbn_get_icon_svg( $atts['icon_name'] ) . '</span>' : '';

    $classes = array('cbn-btn','custom-buy-now-button','cbn-variant-' . sanitize_html_class($atts['variant']),'cbn-size-' . sanitize_html_class($atts['size']),'cbn-anim-' . sanitize_html_class($atts['animation']));
    if ( 'yes' === $atts['fullwidth'] ) $classes[] = 'cbn-w-full';
    if ( 'right' === $atts['icon_pos'] ) $classes[] = 'cbn-icon-right';
    if ( ! empty( $atts['class'] ) ) $classes[] = sanitize_text_field( $atts['class'] );

    $html  = '<a href="' . esc_url( $url ) . '" class="' . esc_attr( implode(' ', $classes) ) . '" data-product-id="' . esc_attr($product_id) . '">';
    if ( 'right' !== $atts['icon_pos'] ) { $html .= $icon; }
    $html .= '<span class="cbn-text">' . esc_html( $atts['text'] ) . '</span>';
    if ( 'right' === $atts['icon_pos'] ) { $html .= $icon; }
    $html .= '</a>';
    return $html;
});

add_action( 'wp_enqueue_scripts', function(){ wp_register_style('cbn-front', CBN_PLUGIN_URL . 'blocks/buy-now/style.css', array(), CBN_PLUGIN_VERSION ); wp_enqueue_style('cbn-front'); });

add_action( 'init', function(){
    if ( function_exists('register_block_type') ) {
        wp_register_script('cbn-block', CBN_PLUGIN_URL . 'blocks/buy-now/block.js', array('wp-blocks','wp-element','wp-components','wp-editor','wp-i18n','wp-data'), CBN_PLUGIN_VERSION, true);
        wp_register_style('cbn-editor', CBN_PLUGIN_URL . 'blocks/buy-now/editor.css', array('wp-edit-blocks'), CBN_PLUGIN_VERSION);
        register_block_type('custom-buy-now/button', array(
            'editor_script'=>'cbn-block','editor_style'=>'cbn-editor','style'=>'cbn-front',
            'render_callback'=>function($attributes){
                $atts = array(
                    'product_id'=> isset($attributes['productId']) ? intval($attributes['productId']) : 0,
                    'quantity'  => isset($attributes['quantity']) ? intval($attributes['quantity']) : 1,
                    'text'      => isset($attributes['text']) ? $attributes['text'] : __( 'Buy Now', 'custom-buy-now' ),
                    'variant'   => isset($attributes['variant']) ? $attributes['variant'] : 'outline',
                    'size'      => isset($attributes['size']) ? $attributes['size'] : 'md',
                    'fullwidth' => ( isset($attributes['fullwidth']) && true === $attributes['fullwidth'] ) ? 'yes' : 'no',
                    'icon'      => ( isset($attributes['showIcon']) && true === $attributes['showIcon'] ) ? 'yes' : 'no',
                    'icon_name' => isset($attributes['iconName']) ? $attributes['iconName'] : 'cart',
                    'icon_pos'  => isset($attributes['iconPos']) ? $attributes['iconPos'] : 'left',
                    'animation' => isset($attributes['animation']) ? $attributes['animation'] : 'lift',
                    'class'     => ' ' . ( isset($attributes['className']) ? $attributes['className'] : '' ),
                );
                return do_shortcode('[custom_buy_now product_id="' . esc_attr($atts['product_id']) . '" quantity="' . esc_attr($atts['quantity']) . '" text="' . esc_attr($atts['text']) . '" variant="' . esc_attr($atts['variant']) . '" size="' . esc_attr($atts['size']) . '" fullwidth="' . esc_attr($atts['fullwidth']) . '" icon="' . esc_attr($atts['icon']) . '" icon_name="' . esc_attr($atts['icon_name']) . '" icon_pos="' . esc_attr($atts['icon_pos']) . '" animation="' . esc_attr($atts['animation']) . '" class="' . esc_attr($atts['class']) . '"]');
            },
        ));
    }
});

add_action( 'plugins_loaded', function(){
    if ( ! did_action('elementor/loaded') ) return;
    add_action( 'elementor/elements/categories_registered', function( $elements_manager ){
        $elements_manager->add_category('cbn-elements', [ 'title'=>__('Custom Buy Now','custom-buy-now'), 'icon'=>'fa fa-plug' ] );
    });
    add_action( 'elementor/widgets/register', function( $widgets_manager ){
        require_once CBN_PLUGIN_DIR . 'includes/elementor-widget.php';
        $widgets_manager->register( new \CBN_Elementor_Buy_Now_Widget() );
    });
});
