(function(wp){
    const { registerBlockType } = wp.blocks;
    const { __ } = wp.i18n;
    const { TextControl, ToggleControl, PanelBody, SelectControl } = wp.components;
    const { InspectorControls } = wp.blockEditor || wp.editor;
    const el = wp.element.createElement;

    const blockIcon = el('svg', { width: 24, height: 24, viewBox: '0 0 24 24' },
        el('path', { d: 'M7 4h-2l-1 2h-2v2h2l3.6 7.59-1.35 2.44a2 2 0 0 0 .25 2.11A2 2 0 0 0 9 20h10v-2H9.42a.25.25 0 0 1-.22-.37l.93-1.63h7.07a2 2 0 0 0 1.79-1.11l3.58-7.16A1 1 0 0 0 22 6H7.21L7 4zm4 16a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm8 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z' }),
        el('path', { d: 'M5 2h6v2H5z' })
    );

    registerBlockType('custom-buy-now/button', {
        title: __('Custom Buy Now', 'custom-buy-now'),
        description: __('Adds the product to cart and goes straight to Checkout.', 'custom-buy-now'),
        icon: blockIcon,
        category: 'woocommerce',
        attributes: {
            productId: { type: 'number', default: 0 },
            quantity:  { type: 'number', default: 1 },
            text:      { type: 'string', default: __('Buy Now', 'custom-buy-now') },
            showIcon:  { type: 'boolean', default: true },
            iconName:  { type: 'string', default: 'cart' },
            iconPos:   { type: 'string', default: 'left' },
            variant:   { type: 'string', default: 'outline' },
            size:      { type: 'string', default: 'md' },
            fullwidth: { type: 'boolean', default: false },
            animation: { type: 'string', default: 'lift' }
        },
        supports: { align: true, html: false, className: true },
        edit: function(props){
            const { attributes, setAttributes, className } = props;
            return [
                el(InspectorControls, {},
                    el(PanelBody, { title: __('Button Settings', 'custom-buy-now'), initialOpen: true },
                        el(TextControl, { label: __('Product ID', 'custom-buy-now'), type: 'number', value: attributes.productId, onChange: (v)=> setAttributes({ productId: parseInt(v || 0) }) }),
                        el(TextControl, { label: __('Quantity', 'custom-buy-now'), type: 'number', value: attributes.quantity, onChange: (v)=> setAttributes({ quantity: parseInt(v || 1) }) }),
                        el(TextControl, { label: __('Button Text', 'custom-buy-now'), value: attributes.text, onChange: (v)=> setAttributes({ text: v }) }),
                        el(ToggleControl, { label: __('Show Icon', 'custom-buy-now'), checked: !!attributes.showIcon, onChange: (v)=> setAttributes({ showIcon: !!v }) }),
                        el(SelectControl, { label: __('Icon', 'custom-buy-now'), value: attributes.iconName, options: [
                            { label: __('Cart', 'custom-buy-now'), value: 'cart' },
                            { label: __('Bag', 'custom-buy-now'), value: 'bag' },
                            { label: __('Bolt', 'custom-buy-now'), value: 'bolt' },
                            { label: __('Flash', 'custom-buy-now'), value: 'flash' },
                            { label: __('Credit Card', 'custom-buy-now'), value: 'credit' },
                            { label: __('Arrow', 'custom-buy-now'), value: 'arrow' },
                            { label: __('Check', 'custom-buy-now'), value: 'check' },
                            { label: __('Star', 'custom-buy-now'), value: 'star' },
                            { label: __('Tag', 'custom-buy-now'), value: 'tag' },
                        ], onChange: (v)=> setAttributes({ iconName: v }) }),
                        el(SelectControl, { label: __('Icon Position', 'custom-buy-now'), value: attributes.iconPos, options: [
                            { label: __('Left', 'custom-buy-now'), value: 'left' },
                            { label: __('Right', 'custom-buy-now'), value: 'right' },
                        ], onChange: (v)=> setAttributes({ iconPos: v }) }),
                        el(SelectControl, { label: __('Variant', 'custom-buy-now'), value: attributes.variant, options: [
                            { label: __('Outline (default)', 'custom-buy-now'), value: 'outline' },
                            { label: __('Solid (dark)', 'custom-buy-now'), value: 'solid' },
                            { label: __('Primary (Woo)', 'custom-buy-now'), value: 'primary' },
                            { label: __('Ghost', 'custom-buy-now'), value: 'ghost' },
                            { label: __('Link', 'custom-buy-now'), value: 'link' },
                        ], onChange: (v)=> setAttributes({ variant: v }) }),
                        el(SelectControl, { label: __('Size', 'custom-buy-now'), value: attributes.size, options: [
                            { label: __('Small', 'custom-buy-now'), value: 'sm' },
                            { label: __('Medium', 'custom-buy-now'), value: 'md' },
                            { label: __('Large', 'custom-buy-now'), value: 'lg' },
                        ], onChange: (v)=> setAttributes({ size: v }) }),
                        el(ToggleControl, { label: __('Full Width', 'custom-buy-now'), checked: !!attributes.fullwidth, onChange: (v)=> setAttributes({ fullwidth: !!v }) }),
                        el(SelectControl, { label: __('Animation', 'custom-buy-now'), value: attributes.animation, options: [
                            { label: __('Lift (default)', 'custom-buy-now'), value: 'lift' },
                            { label: __('Pulse', 'custom-buy-now'), value: 'pulse' },
                            { label: __('Wiggle (icon)', 'custom-buy-now'), value: 'wiggle' },
                            { label: __('None', 'custom-buy-now'), value: 'none' },
                        ], onChange: (v)=> setAttributes({ animation: v }) })
                    )
                ),
                el('div', { className: className, style: { border: '1px dashed #ccd', padding: '12px', borderRadius: '6px' } },
                    el('p', { style: { margin: 0, fontWeight: '600' } }, __('Custom Buy Now Button (Preview)', 'custom-buy-now')),
                    el('button', { className: 'button', style: { marginTop: '8px', fontWeight: '700' } },
                        (attributes.showIcon && attributes.iconPos === 'left') ? el('span', { style: { marginRight: '6px' } }, '🛒') : null,
                        attributes.text || __('Buy Now', 'custom-buy-now'),
                        (attributes.showIcon && attributes.iconPos === 'right') ? el('span', { style: { marginLeft: '6px' } }, '🛒') : null
                    )
                )
            ];
        },
        save: function(){ return null; }
    });
})(window.wp);
