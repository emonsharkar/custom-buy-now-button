<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class CBN_Elementor_Buy_Now_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'cbn_buy_now'; }
    public function get_title() { return __( 'Custom Buy Now', 'custom-buy-now' ); }
    public function get_icon() { return 'eicon-cart'; }
    public function get_categories() { return [ 'cbn-elements', 'woocommerce-elements', 'general' ]; }
    public function get_keywords() { return [ 'buy', 'checkout', 'cart', 'woocommerce', 'button' ]; }

    protected function register_controls() {
        $this->start_controls_section( 'content_section', [ 'label' => __( 'Settings', 'custom-buy-now' ), 'tab' => \Elementor\Controls_Manager::TAB_CONTENT, ]);

        $this->add_control( 'product_id', [ 'label' => __( 'Product ID', 'custom-buy-now' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 0, 'min' => 0 ]);
        $this->add_control( 'quantity',   [ 'label' => __( 'Quantity', 'custom-buy-now' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 1, 'min' => 1 ]);
        $this->add_control( 'text',       [ 'label' => __( 'Button Text', 'custom-buy-now' ), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __( 'Buy Now', 'custom-buy-now' ), 'placeholder' => __( 'Buy Now', 'custom-buy-now' ) ]);

        $this->add_control( 'variant', [ 'label' => __( 'Variant', 'custom-buy-now' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'outline',
            'options' => [ 'outline'=>__( 'Outline (default)', 'custom-buy-now' ), 'solid'=>__( 'Solid (dark)', 'custom-buy-now' ), 'primary'=>__( 'Primary (Woo)', 'custom-buy-now' ), 'ghost'=>__( 'Ghost', 'custom-buy-now' ), 'link'=>__( 'Link', 'custom-buy-now' ), ] ]);

        $this->add_control( 'size', [ 'label' => __( 'Size', 'custom-buy-now' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'md',
            'options' => [ 'sm'=>__( 'Small', 'custom-buy-now' ), 'md'=>__( 'Medium', 'custom-buy-now' ), 'lg'=>__( 'Large', 'custom-buy-now' ), ] ]);

        $this->add_control( 'fullwidth', [ 'label'=>__( 'Full Width', 'custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::SWITCHER, 'return_value'=>'yes', 'default'=>'' ]);

        $this->add_control( 'show_icon', [ 'label'=>__( 'Show Icon', 'custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::SWITCHER, 'return_value'=>'yes', 'default'=>'yes' ]);
        $this->add_control( 'use_el_icon', [ 'label'=>__( 'Use Elementor Icon Library', 'custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::SWITCHER, 'return_value'=>'yes', 'default'=>'', 'condition'=>[ 'show_icon'=>'yes' ] ]);
        $this->add_control( 'chosen_icon', [ 'label'=>__( 'Choose Icon', 'custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::ICONS, 'default'=>[ 'value'=>'fas fa-shopping-cart','library'=>'fa-solid' ], 'condition'=>[ 'show_icon'=>'yes', 'use_el_icon'=>'yes' ] ]);
        $this->add_control( 'icon_name', [ 'label'=>__( 'Built‑in Icon', 'custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::SELECT, 'default'=>'cart',
            'options'=>[ 'cart'=>__( 'Cart','custom-buy-now' ), 'bag'=>__( 'Bag','custom-buy-now' ), 'bolt'=>__( 'Bolt','custom-buy-now' ), 'flash'=>__( 'Flash','custom-buy-now' ), 'credit'=>__( 'Credit Card','custom-buy-now' ), 'arrow'=>__( 'Arrow','custom-buy-now' ), 'check'=>__( 'Check','custom-buy-now' ), 'star'=>__( 'Star','custom-buy-now' ), 'tag'=>__( 'Tag','custom-buy-now' ) ],
            'condition'=>[ 'show_icon'=>'yes', 'use_el_icon'=>'' ] ]);
        $this->add_control( 'icon_pos', [ 'label'=>__( 'Icon Position', 'custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::SELECT, 'default'=>'left', 'options'=>[ 'left'=>__( 'Left','custom-buy-now' ), 'right'=>__( 'Right','custom-buy-now' ) ], 'condition'=>[ 'show_icon'=>'yes' ] ]);

        $this->add_control( 'animation', [ 'label'=>__( 'Hover Animation', 'custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::SELECT, 'default'=>'lift', 'options'=>[ 'lift'=>__( 'Lift (default)','custom-buy-now' ), 'pulse'=>__( 'Pulse','custom-buy-now' ), 'wiggle'=>__( 'Wiggle (icon)','custom-buy-now' ), 'none'=>__( 'None','custom-buy-now' ) ] ]);

        $this->end_controls_section();

        $this->start_controls_section( 'style_section', [ 'label' => __( 'Style (Advanced)', 'custom-buy-now' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ]);
        $this->add_responsive_control( 'align', [ 'label'=>__( 'Alignment','custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::CHOOSE, 'options'=>[ 'left'=>[ 'title'=>__( 'Left','custom-buy-now' ), 'icon'=>'eicon-text-align-left' ], 'center'=>[ 'title'=>__( 'Center','custom-buy-now' ), 'icon'=>'eicon-text-align-center' ], 'right'=>[ 'title'=>__( 'Right','custom-buy-now' ), 'icon'=>'eicon-text-align-right' ] ], 'selectors'=>[ '{{WRAPPER}} .cbn-el-wrap'=>'text-align: {{VALUE}};' ], 'default'=>'left' ]);
        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [ 'name'=>'typography', 'selector'=>'{{WRAPPER}} .custom-buy-now-button' ]);
        $this->add_control( 'text_color', [ 'label'=>__( 'Text Color','custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::COLOR, 'selectors'=>[ '{{WRAPPER}} .custom-buy-now-button'=>'color: {{VALUE}};' ] ]);
        $this->add_control( 'bg_color', [ 'label'=>__( 'Background','custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::COLOR, 'selectors'=>[ '{{WRAPPER}} .custom-buy-now-button'=>'background: {{VALUE}};' ] ]);
        $this->add_control( 'border_color', [ 'label'=>__( 'Border Color','custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::COLOR, 'selectors'=>[ '{{WRAPPER}} .custom-buy-now-button'=>'border-color: {{VALUE}};' ] ]);
        $this->add_responsive_control( 'padding', [ 'label'=>__( 'Padding','custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::DIMENSIONS, 'size_units'=>[ 'px','em','%' ], 'selectors'=>{ '{{WRAPPER}} .custom-buy-now-button':'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' } ]);
        $this->add_responsive_control( 'radius', [ 'label'=>__( 'Border Radius','custom-buy-now' ), 'type'=>\Elementor\Controls_Manager::SLIDER, 'size_units'=>[ 'px','%' ], 'range'=>[ 'px'=>[ 'min'=>0, 'max'=>40 ] ], 'selectors'=>[ '{{WRAPPER}} .custom-buy-now-button'=>'border-radius: {{SIZE}}{{UNIT}};' ] ]);
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $product_id = isset( $s['product_id'] ) ? absint( $s['product_id'] ) : 0;
        if ( ! $product_id ) { echo '<div class="cbn-el-wrap"><em>' . esc_html__( 'Select a Product ID', 'custom-buy-now' ) . '</em></div>'; return; }

        if ( isset($s['show_icon']) && 'yes' === $s['show_icon'] && isset($s['use_el_icon']) && 'yes' === $s['use_el_icon'] ) {
            $url = cbn_get_buy_now_url( $product_id, isset($s['quantity']) ? absint($s['quantity']) : 1 );
            $classes = [ 'cbn-btn','custom-buy-now-button', 'cbn-variant-' . ( $s['variant'] ?? 'outline' ), 'cbn-size-' . ( $s['size'] ?? 'md' ), 'cbn-anim-' . ( $s['animation'] ?? 'lift' ) ];
            if ( isset($s['fullwidth']) && 'yes' === $s['fullwidth'] ) $classes[]='cbn-w-full';
            if ( isset($s['icon_pos']) && 'right' === $s['icon_pos'] ) $classes[]='cbn-icon-right';

            echo '<div class="cbn-el-wrap">';
            echo '<a href="' . esc_url($url) . '" class="' . esc_attr(implode(' ', $classes)) . '" data-product-id="' . esc_attr($product_id) . '">';
            if ( empty($s['icon_pos']) || 'left' === $s['icon_pos'] ) {
                echo '<span class="cbn-icon" aria-hidden="true">'; \Elementor\Icons_Manager::render_icon( $s['chosen_icon'], [ 'aria-hidden' => 'true' ] ); echo '</span>';
            }
            echo '<span class="cbn-text">' . ( ! empty($s['text']) ? esc_html($s['text']) : __( 'Buy Now', 'custom-buy-now' ) ) . '</span>';
            if ( isset($s['icon_pos']) && 'right' === $s['icon_pos'] ) {
                echo '<span class="cbn-icon" aria-hidden="true">'; \Elementor\Icons_Manager::render_icon( $s['chosen_icon'], [ 'aria-hidden' => 'true' ] ); echo '</span>';
            }
            echo '</a></div>';
            return;
        }

        $shortcode = sprintf('[custom_buy_now product_id="%d" quantity="%d" text="%s" variant="%s" size="%s" fullwidth="%s" icon="%s" icon_name="%s" icon_pos="%s" animation="%s"]',
            $product_id,
            isset($s['quantity']) ? absint($s['quantity']) : 1,
            isset($s['text']) ? esc_attr($s['text']) : __( 'Buy Now', 'custom-buy-now' ),
            isset($s['variant']) ? esc_attr($s['variant']) : 'outline',
            isset($s['size']) ? esc_attr($s['size']) : 'md',
            ( isset($s['fullwidth']) && 'yes' === $s['fullwidth'] ) ? 'yes' : 'no',
            ( isset($s['show_icon']) && 'yes' === $s['show_icon'] ) ? 'yes' : 'no',
            isset($s['icon_name']) ? esc_attr($s['icon_name']) : 'cart',
            isset($s['icon_pos']) ? esc_attr($s['icon_pos']) : 'left',
            isset($s['animation']) ? esc_attr($s['animation']) : 'lift'
        );
        echo '<div class="cbn-el-wrap">'; echo do_shortcode($shortcode); echo '</div>';
    }
}
